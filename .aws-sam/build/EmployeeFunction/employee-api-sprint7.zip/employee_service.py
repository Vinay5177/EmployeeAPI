
import uuid
import math

from dynamodb_helper import (
    create_employee,
    get_all_employees,
    get_employee,
    update_employee,
    delete_employee
)

from validation import validate_employee

from exceptions import (
    ValidationError,
    NotFoundError,
    DatabaseError
)

from logger import (
    log_info,
    log_error
)


def create_new_employee(data):

    is_valid, message = validate_employee(data)

    if not is_valid:

        log_info(
            "Employee validation failed",
            {
                "reason": message
            }
        )

        raise ValidationError(message)

    employee = {
        "employeeId": str(uuid.uuid4()),
        "name": data["name"],
        "department": data["department"],
        "email": data["email"],
        "salary": data["salary"]
    }

    try:

        create_employee(employee)

        log_info(
            "Employee created",
            {
                "employeeId": employee["employeeId"],
                "department": employee["department"]
            }
        )

        return employee

    except Exception as ex:

        log_error(
            "Failed to create employee",
            error=ex
        )

        raise DatabaseError(
            "Unable to create employee"
        )


def list_employees(filters=None):

    filters = filters or {}

    try:

        employees = get_all_employees()

        department = filters.get("department")
        name = filters.get("name")

        if department:

            employees = [
                emp for emp in employees
                if emp.get("department", "").lower()
                == department.lower()
            ]

        if name:

            employees = [
                emp for emp in employees
                if name.lower()
                in emp.get("name", "").lower()
            ]

        sort_by = filters.get("sortBy")
        order = filters.get("order", "asc")

        allowed_sort_fields = [
            "name",
            "department",
            "salary"
        ]

        if sort_by:

            if sort_by not in allowed_sort_fields:

                raise ValidationError(
                    f"Invalid sort field. Allowed values: {allowed_sort_fields}"
                )

            employees.sort(
                key=lambda x: x.get(sort_by, ""),
                reverse=(order.lower() == "desc")
            )

        try:

            page = int(filters.get("page", 1))
            limit = int(filters.get("limit", 10))

        except ValueError:

            raise ValidationError(
                "page and limit must be numbers"
            )

        if page < 1:
            page = 1

        if limit > 50:
            limit = 50

        total = len(employees)

        total_pages = (
            math.ceil(total / limit)
            if total > 0 else 1
        )

        start = (page - 1) * limit
        end = start + limit

        employees = employees[start:end]

        log_info(
            "Employees listed",
            {
                "page": page,
                "limit": limit,
                "total": total
            }
        )

        return {
            "page": page,
            "limit": limit,
            "total": total,
            "totalPages": total_pages,
            "data": employees
        }

    except (ValidationError, NotFoundError):

        raise

    except Exception as ex:

        log_error(
            "Failed to list employees",
            error=ex
        )

        raise DatabaseError(
            "Unable to retrieve employees"
        )


def find_employee(employee_id):

    try:

        employee = get_employee(employee_id)

        if not employee:

            log_info(
                "Employee not found",
                {
                    "employeeId": employee_id
                }
            )

            raise NotFoundError(
                "Employee not found"
            )

        log_info(
            "Employee retrieved",
            {
                "employeeId": employee_id
            }
        )

        return employee

    except NotFoundError:

        raise

    except Exception as ex:

        log_error(
            "Failed to retrieve employee",
            error=ex
        )

        raise DatabaseError(
            "Unable to retrieve employee"
        )


def modify_employee(employee_id, data):

    is_valid, message = validate_employee(data)

    if not is_valid:

        log_info(
            "Employee update validation failed",
            {
                "employeeId": employee_id,
                "reason": message
            }
        )

        raise ValidationError(message)

    try:

        update_employee(
            employee_id,
            data
        )

        log_info(
            "Employee updated",
            {
                "employeeId": employee_id
            }
        )

        return {
            "message": "Employee updated successfully"
        }

    except Exception as ex:

        log_error(
            "Failed to update employee",
            error=ex
        )

        raise DatabaseError(
            "Unable to update employee"
        )


def remove_employee(employee_id):

    try:

        delete_employee(employee_id)

        log_info(
            "Employee deleted",
            {
                "employeeId": employee_id
            }
        )

        return {
            "message": "Employee deleted successfully"
        }

    except Exception as ex:

        log_error(
            "Failed to delete employee",
            error=ex
        )

        raise DatabaseError(
            "Unable to delete employee"
        )
