
import json

from authorization import is_admin

from employee_service import (
    create_new_employee,
    list_employees,
    find_employee,
    modify_employee,
    remove_employee
)

from exceptions import EmployeeAPIError

from utils import build_response

from logger import (
    log_info,
    log_error,
    start_timer,
    elapsed_ms
)

from config import Config


def lambda_handler(event, context):

    timer = start_timer()

    request_context = event.get(
        "requestContext",
        {}
    )

    request_id = request_context.get(
        "requestId",
        "local-test"
    )

    claims = (
        request_context
        .get("authorizer", {})
        .get("jwt", {})
        .get("claims", {})
    )

    user_email = claims.get(
        "email",
        "anonymous"
    )

    role = claims.get(
        "custom:role",
        "unknown"
    )

    method = (
        request_context
        .get("http", {})
        .get("method")
    )

    path = (
        request_context
        .get("http", {})
        .get("path")
    )

    log_info(
        "Request started",
        {
            "environment": Config.ENVIRONMENT,
            "requestId": request_id,
            "user": user_email,
            "role": role,
            "method": method,
            "path": path
        }
    )

    try:

        path_parameters = event.get(
            "pathParameters"
        )

        query_params = event.get(
            "queryStringParameters"
        ) or {}

        body = {}

        if event.get("body"):

            body = json.loads(
                event["body"]
            )

        log_info(
            "Request details",
            {
                "requestId": request_id,
                "pathParameters": path_parameters,
                "queryParameters": query_params
            }
        )

        status = 200

        # -------------------------
        # POST
        # -------------------------

        if method == "POST":

            if not is_admin(event):

                raise EmployeeAPIError(
                    "Admin access required"
                )

            result = create_new_employee(
                body
            )

            status = 201

        # -------------------------
        # GET
        # -------------------------

        elif method == "GET":

            if (
                path_parameters
                and path_parameters.get("employeeId")
            ):

                result = find_employee(
                    path_parameters["employeeId"]
                )

            else:

                result = list_employees(
                    query_params
                )

        # -------------------------
        # PUT
        # -------------------------

        elif method == "PUT":

            if not is_admin(event):

                raise EmployeeAPIError(
                    "Admin access required"
                )

            result = modify_employee(
                path_parameters["employeeId"],
                body
            )

        # -------------------------
        # DELETE
        # -------------------------

        elif method == "DELETE":

            if not is_admin(event):

                raise EmployeeAPIError(
                    "Admin access required"
                )

            result = remove_employee(
                path_parameters["employeeId"]
            )

        else:

            raise EmployeeAPIError(
                "Unsupported method"
            )

        log_info(
            "Request completed",
            {
                "environment": Config.ENVIRONMENT,
                "requestId": request_id,
                "statusCode": status,
                "durationMs": elapsed_ms(timer)
            }
        )

        return build_response(
            status,
            {
                "success": True,
                "data": result
            }
        )

    except EmployeeAPIError as ex:

        log_error(
            "API exception",
            error=ex,
            data={
                "requestId": request_id
            }
        )

        return build_response(
            ex.status_code,
            {
                "success": False,
                "errorCode": ex.error_code,
                "message": ex.message
            }
        )

    except Exception as ex:

        log_error(
            "Unhandled exception",
            error=ex,
            data={
                "requestId": request_id
            }
        )

        return build_response(
            500,
            {
                "success": False,
                "message": "Internal server error"
            }
        )
